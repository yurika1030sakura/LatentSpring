LatentSpring submission draft. Compile main.tex with pdfLaTeX, BibTeX, then pdfLaTeX twice.
The rotor animation shows prescribed rotations, not molecular dynamics. The current method illustration uses fixed raw generated coordinates with inferred connectivity.
