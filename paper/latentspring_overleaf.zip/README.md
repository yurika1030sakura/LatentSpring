# LatentSpring

Physics-Informed Molecular Flow Matching from Atomic Composition.

Set `main.tex` as the main document and compile with pdfLaTeX and BibTeX.
This project includes every referenced section, figure, bibliography entry, and local style file. The manuscript is an anonymous ICLR 2027 submission draft.

When included, `supplement/generation.gif` shows an actual recorded coordinate-flow trajectory, and `supplement/rotor_scan.gif` shows a prescribed methyl rotation. These animations are supplementary files; the PDF uses static snapshots. Neither animation is a claim of physical molecular-dynamics simulation.
