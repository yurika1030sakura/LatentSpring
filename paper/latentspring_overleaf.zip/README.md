LatentSpring submission draft. Compile main.tex with pdfLaTeX, BibTeX, then pdfLaTeX twice.
Animations show generation or prescribed rotations, not molecular dynamics.
