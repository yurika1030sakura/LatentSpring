# LatentSpring

Physics-Informed Molecular Flow Matching from Atomic Composition.

Set `main.tex` as the main document and compile with pdfLaTeX and BibTeX.
This project includes every referenced section, figure, bibliography entry, and local style file. The manuscript is an anonymous ICLR 2027 submission draft.
